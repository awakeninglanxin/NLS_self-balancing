"""
NLS Self-Balancing Web v2.0 — 经络实时平衡仪 + Web仪表盘
启动: python balancer_web.py → 浏览器打开 http://localhost:8080
修复: loop异常处理 + 器官名称实时显示 + 改善/恶化详情
"""
import serial, struct, time, math, json, os, threading, traceback, random
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

COM_PORT = "COM4"
BASELINE_FILE = os.path.join(os.path.dirname(__file__), "nls_baseline.json")
B9_RANGE = range(1, 36)

WUXING_CORRECTION = {"木": 1.0, "火": 1.5, "土": 1.0, "金": 1.2, "水": 0.8}

B9_MAP = {
    1: ("极低频/基础", "土"), 2: ("极低频/共振", "土"),
    3: ("极低频/调和", "土"), 4: ("超低频/A", "水"),
    5: ("超低频/B", "水"), 6: ("超低频/C", "水"),
    7: ("低频/A", "金"), 8: ("低频/B", "金"),
    9: ("低频/C", "金"), 10: ("中低频/A", "木"),
    11: ("中低频/B", "木"), 12: ("中低频/C", "木"),
    13: ("过渡频/A", "火"),
    14: ("骨骼/基础", "土"), 15: ("肌肉/结缔", "土"),
    16: ("皮肤/皮毛", "金"), 17: ("淋巴/免疫", "火"),
    18: ("消化/肠道", "金"), 19: ("消化/胃部", "土"),
    20: ("肝脏/代谢", "木"), 21: ("胰腺/内分泌", "土"),
    22: ("脾脏/血液", "土"), 23: ("肺部/呼吸", "金"),
    24: ("甲状腺", "火"),   25: ("肾脏/肾上腺", "水"),
    26: ("心血管", "火"),   27: ("心脏", "火"),
    28: ("神经系统", "火"), 29: ("脑/中枢", "火"),
    30: ("下丘脑", "火"),   31: ("松果体", "火"),
    32: ("超高频/A", "木"), 33: ("超高频/B", "木"),
    34: ("超高频/C", "木"), 35: ("极高频", "火"),
}


# ========== 阴阳数列谐波疗愈 ==========
# 太阳数列 (CH1): 2^n = 1,2,4,8,16,32
# 太阴数列 (CH2): Fibonacci = 1,1,2,3,5,8,13,21,34
SUN_SEQ = [1, 2, 4, 8, 16, 32]
MOON_SEQ = [1, 1, 2, 3, 5, 8, 13, 21, 34]

def _nearest(b9, seq):
    """返回 b9 到数列最近项的距离"""
    return min(abs(b9 - s) for s in seq)

# 预计算 35 个 b9 的太阳/太阴权重
YINYANG_WEIGHT = {}
for _b9 in B9_RANGE:
    d_sun = _nearest(_b9, SUN_SEQ)
    d_moon = _nearest(_b9, MOON_SEQ)
    w_sun = 1.0 / (1 + d_sun)
    w_moon = 1.0 / (1 + d_moon)
    total = w_sun + w_moon
    YINYANG_WEIGHT[_b9] = {
        "sun": round(w_sun / total, 2),
        "moon": round(w_moon / total, 2),
        "sun_b9": min(SUN_SEQ, key=lambda s: abs(_b9 - s)),
        "moon_b9": min(MOON_SEQ, key=lambda s: abs(_b9 - s)),
    }


class Balancer:
    def __init__(self):
        self.ser = None
        self.baseline = {}
        self.running = False
        self.calibrating = False
        self._algo_queue = []
        self._batch_num = 0
        self.status = {
            "playing": False, "scanning": False, "round": 0,
            "deltas": {}, "verify": {}, "log": [],
            "improved": 0, "worsened": 0, "connected": False,
            "has_baseline": False,
            "algo": "yinyang",  # "legacy" / "yinyang" / "fusion" / "ab"
            "ab_legacy": {"imp": 0, "wors": 0, "rounds": 0},
            "ab_yinyang": {"imp": 0, "wors": 0, "rounds": 0},
            "ab_fusion": {"imp": 0, "wors": 0, "rounds": 0},
        }
        self._lock = threading.Lock()
        self.load_baseline()

    def load_baseline(self):
        if os.path.exists(BASELINE_FILE):
            with open(BASELINE_FILE) as f:
                self.baseline = {int(k): v for k, v in json.load(f).items()}
            self.status["has_baseline"] = len(self.baseline) >= 18

    def connect(self):
        try:
            self.ser = serial.Serial(COM_PORT, 115200, timeout=0.5, write_timeout=0.5)
            self.status["connected"] = True
            return True
        except:
            self.status["connected"] = False
            return False

    def add_log(self, msg):
        with self._lock:
            self.status["log"].insert(0, msg)
            if len(self.status["log"]) > 50:
                self.status["log"].pop()

    def probe(self, b9, b11=15):
        if not self.ser or not self.ser.is_open:
            return [100] * 256
        cmd = bytearray(128)
        cmd[9] = b9; cmd[11] = b11; cmd[13] = b9; cmd[15] = b11
        self.ser.reset_input_buffer()
        self.ser.write(bytes(cmd))
        time.sleep(0.08)
        return list(self.ser.read(256))

    def scan(self):
        """扫描全部18频段，实时更新UI"""
        deltas = {}
        for b9 in B9_RANGE:
            resp = self.probe(b9)
            if len(resp) == 256:
                avg = sum(resp) / 256
                bl = self.baseline.get(b9, 105)
                d = round(avg - bl, 1)
                deltas[b9] = d
                organ, wuxing = B9_MAP.get(b9, ('?', '土'))
                freq = 7.3728 * (2 ** (b9 / 4)) * 3
                yy = YINYANG_WEIGHT.get(b9, {"sun": 0.5, "moon": 0.5, "sun_b9": b9, "moon_b9": b9})
                with self._lock:
                    self.status["deltas"][str(b9)] = {
                        "b9": b9, "organ": organ, "wuxing": wuxing,
                        "freq": int(freq), "delta": d, "verified": None,
                        "sun": yy["sun"], "moon": yy["moon"],
                        "sun_b9": yy["sun_b9"], "moon_b9": yy["moon_b9"],
                    }
            time.sleep(0.02)
        return deltas

    def balance_legacy(self, deltas):
        """旧算法: CH1=CH2 同频异幅"""
        balanced = []
        for b9, delta in sorted(deltas.items(), key=lambda x: -abs(x[1])):
            if abs(delta) < 4: continue
            organ, wuxing = B9_MAP.get(b9, ('?', '土'))
            corr = WUXING_CORRECTION.get(wuxing, 1.0)
            adjust = min(int(abs(delta) * 0.5 * corr), 60)
            b11 = max(3, 15 - adjust) if delta > 0 else min(80, 15 + adjust)
            b15 = min(80, 15 + adjust) if delta > 0 else max(3, 15 - adjust)
            if self.ser and self.ser.is_open:
                cmd = bytearray(128)
                cmd[9] = b9; cmd[11] = b11; cmd[13] = b9; cmd[15] = b15
                self.ser.write(bytes(cmd))
            balanced.append({"b9": b9, "organ": organ, "delta": delta, "direction": "↓" if delta > 0 else "↑"})
            time.sleep(0.10)
        return balanced

    def balance(self, deltas):
        """阴阳数列双频反相: CH1=太阳(2^n谐波) CH2=太阴(Fibonacci谐波)"""
        balanced = []
        for b9, delta in sorted(deltas.items(), key=lambda x: -abs(x[1])):
            if abs(delta) < 4:
                continue
            organ, wuxing = B9_MAP.get(b9, ('?', '土'))
            corr = WUXING_CORRECTION.get(wuxing, 1.0)
            yy = YINYANG_WEIGHT.get(b9, {"sun": 0.5, "moon": 0.5, "sun_b9": b9, "moon_b9": b9})
            adjust = min(int(abs(delta) * 0.5 * corr), 60)

            # CH1 太阳: 用最近的 2^n 频率 + 太阳权重振幅
            sun_b9 = yy["sun_b9"]
            sun_amp = max(3, 15 - int(adjust * yy["sun"])) if delta > 0 else min(80, 15 + int(adjust * yy["sun"]))
            # CH2 太阴: 用最近的 Fibonacci 频率 + 太阴权重振幅
            moon_b9 = yy["moon_b9"]
            moon_amp = min(80, 15 + int(adjust * yy["moon"])) if delta > 0 else max(3, 15 - int(adjust * yy["moon"]))

            if self.ser and self.ser.is_open:
                cmd = bytearray(128)
                cmd[9] = sun_b9; cmd[11] = sun_amp
                cmd[13] = moon_b9; cmd[15] = moon_amp
                self.ser.write(bytes(cmd))

            direction = "↓" if delta > 0 else "↑"
            balanced.append({
                "b9": b9, "organ": organ, "delta": delta, "direction": direction,
                "ch1": f"b9={sun_b9} a={sun_amp}", "ch2": f"b9={moon_b9} a={moon_amp}",
            })
            time.sleep(0.10)
        return balanced

    def balance_fusion(self, deltas):
        """融合算法: 同频反相地基 + CH1太阳/CH2太阴双轨微调"""
        balanced = []
        for b9, delta in sorted(deltas.items(), key=lambda x: -abs(x[1])):
            if abs(delta) < 4:
                continue
            organ, wuxing = B9_MAP.get(b9, ('?', '土'))
            corr = WUXING_CORRECTION.get(wuxing, 1.0)
            adjust = min(int(abs(delta) * 0.5 * corr), 60)

            # 地基层: 标准反相振幅（归零力）
            b11 = max(3, 15 - adjust) if delta > 0 else min(80, 15 + adjust)
            b15 = min(80, 15 + adjust) if delta > 0 else max(3, 15 - adjust)

            # 谐波层: CH1→太阳(2^n)微调, CH2→太阴(Fibonacci)微调
            # b9 不替换, 两通道围绕 b9 对称展开, 偏移 ≤±2
            yy = YINYANG_WEIGHT.get(b9, {})
            raw_sun = yy.get("sun_b9", b9)
            raw_moon = yy.get("moon_b9", b9)
            ch1_b9 = max(b9 - 2, min(b9 + 2, raw_sun))
            ch2_b9 = max(b9 - 2, min(b9 + 2, raw_moon))

            if self.ser and self.ser.is_open:
                cmd = bytearray(128)
                cmd[9] = ch1_b9; cmd[11] = b11
                cmd[13] = ch2_b9; cmd[15] = b15
                self.ser.write(bytes(cmd))

            balanced.append({
                "b9": b9, "organ": organ, "delta": delta,
                "direction": "↓" if delta > 0 else "↑",
                "ch1": f"☀b9={ch1_b9} a={b11}", "ch2": f"☽b9={ch2_b9} a={b15}",
            })
            time.sleep(0.10)
        return balanced

    def verify(self, before):
        """复扫验证：对比治疗前后偏差"""
        imp, wors = 0, 0
        vrf = {}
        for b9, bf in before.items():
            if abs(bf) < 3:
                continue
            resp = self.probe(b9)
            avg = sum(resp) / 256 if len(resp) == 256 else 100
            after = round(avg - self.baseline.get(b9, 105), 1)
            diff = round(abs(bf) - abs(after), 1)
            vrf[b9] = {"before": bf, "after": after, "diff": diff}
            if diff > 0.5:
                imp += 1
            elif diff < -0.5:
                wors += 1
            # 更新单个器官验证结果
            organ, _ = B9_MAP.get(b9, ('?', '土'))
            with self._lock:
                if str(b9) in self.status["deltas"]:
                    self.status["deltas"][str(b9)]["verified"] = diff
            time.sleep(0.02)
        return vrf, imp, wors

    def calibrate(self):
        self.calibrating = True
        try:
            self.add_log("📐 校准基线中…传感器请悬空")
            raw = {}
            for b9 in B9_RANGE:
                resp = self.probe(b9)
                raw[b9] = round(sum(resp) / len(resp), 1) if len(resp) == 256 else 105.0
            self.baseline = raw
            with open(BASELINE_FILE, 'w') as f:
                json.dump(raw, f, indent=2)
            self.add_log("✅ 基线校准完成")
            self.status["has_baseline"] = True
            return raw
        except Exception as e:
            self.add_log(f"❌ 校准失败: {str(e)[:60]}")
        finally:
            self.calibrating = False

    def loop(self):
        """主循环：扫描→治疗→验证，带错误保护"""
        self.running = True
        self.add_log("── 动态平衡启动 ──")
        try:
            while self.running:
                with self._lock:
                    self.status["round"] += 1
                    round_num = self.status["round"]
                    self.status["playing"] = True
                    self.status["scanning"] = True
                    self.status["deltas"] = {}

                # 第1步：扫描
                self.add_log(f"🔍 第{round_num}轮 扫描中…")
                deltas = self.scan()
                abn = {k: v for k, v in deltas.items() if abs(v) > 4}

                with self._lock:
                    self.status["scanning"] = False
                    self.status["deltas"] = self.status["deltas"]  # 已实时填充

                if abn:
                    algo = self.status.get("algo", "yinyang")
                    # 三维交替: 随机打乱每批出场顺序，保证每3轮各算法恰1次
                    if algo == "ab":
                        if not self._algo_queue:
                            self._batch_num += 1
                            self._algo_queue = ["legacy", "yinyang", "fusion"]
                            random.shuffle(self._algo_queue)
                            batch_labels = [({"legacy": "同频反相", "yinyang": "☀☽双频", "fusion": "⚡融合"}[a]) for a in self._algo_queue]
                            self.add_log(f"─── 第{self._batch_num}遍: {' → '.join(batch_labels)} ───")
                        use_algo = self._algo_queue.pop(0)
                        self.status["current_algo"] = use_algo
                    else:
                        use_algo = algo

                    abn_list = sorted(abn.items(), key=lambda x: -abs(x[1]))
                    organ_names = [B9_MAP.get(b9, ('?', ''))[0] for b9, _ in abn_list[:5]]
                    algo_labels = {"legacy": "同频反相", "yinyang": "☀☽双频", "fusion": "⚡融合"}
                    algo_label = algo_labels.get(use_algo, use_algo)
                    self.add_log(f"  ⚡ {len(abn)}项异常: {', '.join(organ_names[:3])} [{algo_label}]")

                    if use_algo == "yinyang":
                        balanced = self.balance(deltas)
                    elif use_algo == "fusion":
                        balanced = self.balance_fusion(deltas)
                    else:
                        balanced = self.balance_legacy(deltas)

                    self.add_log(f"  🔊 已治 {len(balanced)}项")
                    # 日志简化

                    # 第3步：验证
                    vrf, imp, wors = self.verify(deltas)
                    with self._lock:
                        self.status["improved"] = imp
                        self.status["worsened"] = wors
                        self.status["verify"] = {str(k): v for k, v in vrf.items()}
                        # A/B 统计
                        ab_key = "ab_" + use_algo
                        if ab_key in self.status:
                            self.status[ab_key]["imp"] += imp
                            self.status[ab_key]["wors"] += wors
                            self.status[ab_key]["rounds"] += 1

                    # 逐器官记录
                    for b9, v in sorted(vrf.items(), key=lambda x: -abs(x[1]["diff"])):
                        organ, _ = B9_MAP.get(b9, ('?', ''))
                        if v["diff"] > 0.5:
                            self.add_log(f"  ✅ {organ} ↓{abs(v['diff']):.1f}")
                        elif v["diff"] < -0.5:
                            self.add_log(f"  ⚠ {organ} ↑{abs(v['diff']):.1f}")

                    self.add_log(f"  [第{round_num}轮] 改善{imp} / 恶化{wors}  [{algo_label}]")

                    # 自动报告: 每种算法≥12轮时生成对比
                    if algo == "ab":
                        ab_stats = [
                            (self.status["ab_legacy"]["rounds"], "同频反相"),
                            (self.status["ab_yinyang"]["rounds"], "☀☽双频"),
                            (self.status["ab_fusion"]["rounds"], "⚡融合"),
                        ]
                        all_12 = all(r >= 12 for r, _ in ab_stats)
                        if all_12:
                            # 生成报告前先打印累计（确保顺序不乱）
                            progress = ', '.join(f"{n}:{r}轮" for r, n in ab_stats)
                            self.add_log(f"  📊 每算法满12轮: {progress}  (已完{self._batch_num}遍)")
                            self._auto_report()
                            # 重置为0而不是减12，避免漂移
                            for ab_key in ["ab_legacy", "ab_yinyang", "ab_fusion"]:
                                self.status[ab_key]["rounds"] = 0
                else:
                    self.add_log(f"  ✓ 第{round_num}轮 全部平衡")

                # 轮间间隔
                wait_end = time.time() + 3.0
                while self.running and time.time() < wait_end:
                    time.sleep(0.2)

        except Exception as e:
            self.add_log(f"❌ 错误: {str(e)[:80]}")
            traceback.print_exc()
        finally:
            self.running = False
            with self._lock:
                self.status["playing"] = False
                self.status["scanning"] = False
            self.add_log("⏹ 循环已停止")

    def _auto_report(self):
        leg = self.status["ab_legacy"]
        yy = self.status["ab_yinyang"]
        fus = self.status["ab_fusion"]

        def rate(s):
            imp, wors, rds = s.get("imp", 0), s.get("wors", 0), s.get("rounds", 0)
            total = imp + wors
            pct = round(imp / total * 100, 1) if total > 0 else 0
            return pct, f"{pct}% ({rds}轮 改善{imp}/恶化{wors})"

        p_leg, r_leg = rate(leg)
        p_yy, r_yy = rate(yy)
        p_fus, r_fus = rate(fus)

        best = max([(p_leg, "同频反相"), (p_yy, "☀☽双频"), (p_fus, "⚡融合")], key=lambda x: x[0])

        # 读出当前批次的实际顺序（从日志里取最后一条以"─── 第"开头的行）
        # 但更好的方式: 从 _batch_num 和队列倒推——队列刚耗尽说明最后一批已完成

        report = (
            f"╔═══ NLS 三维算法对比报告 (第{self._batch_num}遍/共36轮) ═══\n"
            f"║ 时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"║ 说明: 每算法各12轮, 出场顺序每3轮随机打乱\n"
            f"║────────────────────────────────────────\n"
            f"║ ① 同频反相: {r_leg}\n"
            f"║ ② ☀☽双频:   {r_yy}\n"
            f"║ ③ ⚡融合:    {r_fus}\n"
            f"║────────────────────────────────────────\n"
            f"║ 🏆 当前最优: {best[1]} ({best[0]}%)\n"
            f"╚══════════════════════════════════════════\n"
        )
        self.add_log(report)

        report_path = os.path.join(os.path.dirname(__file__), "algo_compare_report.txt")
        with open(report_path, 'a', encoding='utf-8') as f:
            f.write(report + "\n")
        self.add_log(f"📄 对比报告已保存 → {report_path}")

    def disconnect(self):
        self.running = False
        self.status["connected"] = False
        if self.ser and self.ser.is_open:
            self.ser.close()
            self.ser = None


# ========== Web 界面 ==========
HTML = r"""<!DOCTYPE html><html lang="zh"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NLS Self-Balancing</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui;background:#0a0a0f;color:#e0e0e0;max-width:640px;margin:0 auto;padding:10px}
h1{font-size:18px;text-align:center;color:#00ff88;margin:6px 0}
.card{background:#141420;border-radius:12px;padding:12px;margin:6px 0;border:1px solid #222}
.row{display:flex;justify-content:space-between;align-items:center;padding:4px 0;font-size:12px;border-bottom:1px solid #1a1a2e}
.row:last-child{border:0}
.badge{padding:1px 6px;border-radius:8px;font-size:10px;font-weight:bold;min-width:44px;text-align:center}
.conn-badge{padding:3px 10px;border-radius:12px;font-size:11px;font-weight:bold}
.btn{padding:10px 18px;border:0;border-radius:20px;font-size:13px;cursor:pointer;margin:3px;font-weight:bold;transition:opacity .2s}
.btn:disabled{opacity:.4}
.btn-start{background:#00ff88;color:#000}
.btn-stop{background:#ff4444;color:#fff}
.btn-cal{background:#333;color:#aaa}
.btns{text-align:center;margin:8px 0}
.log{font-size:10px;color:#666;max-height:120px;overflow-y:auto;margin-top:4px;line-height:1.4}
.log div{padding:1px 0;border-bottom:1px solid #0d0d14}
.stats{font-size:12px;color:#aaa;text-align:center;padding:4px 0}
.stats b{color:#00ff88}
canvas{display:block;margin:0 auto;border-radius:8px}
.tabs{display:flex;gap:4px;margin:6px 0}
.tab{padding:5px 12px;border-radius:12px;font-size:11px;cursor:pointer;background:#222;color:#888;border:0}
.tab.active{background:#7c4dff;color:#fff}
.view{display:none}
.view.active{display:block}
#dbg{font-size:9px;color:#f44;background:#2a0a0a;padding:4px 8px;border-radius:4px;margin:4px 0;display:none}
.overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.85);z-index:100;display:flex;align-items:center;justify-content:center;flex-direction:column}
.overlay.hidden{display:none}
.overlay .box{background:#141420;border:2px solid #7c4dff;border-radius:16px;padding:24px;text-align:center;max-width:320px}
.overlay h2{color:#ffaa00;font-size:16px;margin-bottom:8px}
.overlay p{color:#aaa;font-size:13px;margin:8px 0;line-height:1.5}
.overlay .btn{display:inline-block;margin-top:12px;padding:12px 32px;font-size:15px}
</style></head><body>
<div class="overlay" id="calOverlay">
  <div class="box">
    <h2>⚠ 首次使用 — 请校准基线</h2>
    <p>将手环<b style="color:#ff4444">悬空</b>（不接触皮肤）<br>点击下方按钮开始自动扫描</p>
    <p style="font-size:11px;color:#666">手环需要采集环境本底噪音<br>作为后续诊断的"零参考面"</p>
    <button class="btn btn-cal" id="calStartBtn" onclick="doCalibrate()" style="background:#7c4dff;color:#fff;font-size:15px;padding:14px 36px">📐 开始校准</button>
    <p id="calStatus" style="font-size:12px;color:#ffaa00;margin-top:12px"></p>
  </div>
</div>
<h1>🧬 NLS 动态平衡</h1>
<div id="conn_status" style="text-align:center;margin-bottom:6px">
  <span id="conn_badge" class="conn-badge" style="background:#333;color:#888">检测中...</span>
</div>
<div class="btns">
  <button class="btn btn-start" id="btnStart" onclick="api('/start')">▶ 启动平衡</button>
  <button class="btn btn-stop" id="btnStop" onclick="api('/stop')" style="display:none">⏹ 停止</button>
  <button class="btn btn-stop cmp-btn" id="btnCmp" onclick="stopAndCompare()" style="display:none">📊 停止&对比</button>
  <button class="btn btn-cal" onclick="api('/calibrate')">📐 校准基线</button>
</div>
<div class="card" style="padding:8px 12px">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <b>⚖ 三维对比</b>
    <span id="baselineDot" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#f44;margin-right:4px" title="基线状态"></span>
  </div>
  <div style="display:flex;gap:4px;margin-top:4px;flex-wrap:wrap">
    <button class="algo-btn active" onclick="setAlgo('yinyang')" id="abYY">☀☽ 双频</button>
    <button class="algo-btn" onclick="setAlgo('legacy')" id="abOLD">同频反相</button>
    <button class="algo-btn" onclick="setAlgo('fusion')" id="abFUS">⚡融合</button>
    <button class="algo-btn" onclick="setAlgo('ab')" id="abAB">🔄 三维交替</button>
  </div>
  <div id="abStats" style="font-size:10px;color:#aaa;margin-top:4px"></div>
  <div id="abBars" style="display:flex;gap:2px;height:6px;margin-top:2px;border-radius:3px;overflow:hidden">
    <div id="barLeg" style="background:#ffaa00;width:33%;transition:width .3s"></div>
    <div id="barYY" style="background:#7c4dff;width:33%;transition:width .3s"></div>
    <div id="barFus" style="background:#44dd88;width:33%;transition:width .3s"></div>
  </div>
</div>
<style>.algo-btn{padding:5px 8px;border-radius:10px;font-size:10px;cursor:pointer;background:#222;color:#888;border:0}.algo-btn.active{background:#7c4dff;color:#fff}.cmp-btn{background:#ff6600;color:#000;font-weight:bold}</style>
<div class="stats" id="stats"></div>
<div class="card" id="resultCard" style="display:none;border:2px solid #7c4dff">
  <b>📊 A/B 对比结论</b>
  <div id="resultBody" style="font-size:12px;line-height:1.6;margin-top:6px"></div>
</div>
<div id="dbg"></div>

<div class="tabs">
  <button class="tab active" onclick="switchTab('radar')">五行</button>
  <button class="tab" onclick="switchTab('list')">列表</button>
</div>

<div class="card view active" id="view_radar">
  <b style="color:#888;font-size:11px">☯ 五行平衡雷达图</b>
  <canvas id="cvRadar" width="584" height="260"></canvas>
</div>
<div class="card view" id="view_list">
  <b>📊 频段偏差</b>
  <div id="deltas" style="max-height:380px;overflow-y:auto"></div>
</div>

<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <b>📝 日志</b>
    <button onclick="copyLogs()" style="background:#333;color:#aaa;border:0;border-radius:8px;padding:3px 10px;font-size:10px;cursor:pointer">📋 复制全部</button>
  </div>
  <div class="log" id="log"></div>
</div>
<script>
var dbg=document.getElementById('dbg');
function debug(msg){dbg.style.display='block';dbg.textContent=msg;console.log(msg)}
function deltaColor(d){var a=Math.abs(d);return a>8?'#ff4444':a>4?'#ffaa00':'#00ff88'}

function drawRadar(items){
  var c=document.getElementById('cvRadar');
  if(!c){debug('cvRadar missing');return}
  var w=c.width,h=c.height,ctx=c.getContext('2d');
  ctx.clearRect(0,0,w,h);
  if(!items||!items.length){debug('radar:no items');ctx.fillStyle='#555';ctx.font='13px system-ui';ctx.textAlign='center';ctx.fillText('等待扫描数据…',w/2,h/2);return}

  // Aggregate by wuxing using index (avoid encoding issues)
  var names=['土','金','水','木','火'],colors=['#ffaa00','#aaa','#4488ff','#44ff44','#ff4444'];
  var sums=[0,0,0,0,0],cnts=[0,0,0,0,0];
  for(var i=0;i<items.length;i++){
    var wu=items[i].wuxing;
    for(var j=0;j<5;j++){if(wu===names[j]){sums[j]+=Math.abs(items[i].delta);cnts[j]++;break}}
  }
  var vals=[];for(var i=0;i<5;i++){vals.push(cnts[i]>0?sums[i]/cnts[i]:0)}
  //debug('radar:vals='+vals.map(function(v){return v.toFixed(1)}).join(',')+' sums='+sums.join(',')+' cnts='+cnts.join(','));

  var cx=w/2,cy=h/2+5,radius=Math.min(cx,cy)-50,n=5;
  var mx=Math.max(10,Math.max.apply(null,vals.map(Math.abs)));
  // Rings
  for(var ring=1;ring<=3;ring++){
    ctx.beginPath();ctx.strokeStyle='#1a1a2e';ctx.lineWidth=1;
    for(var i=0;i<n;i++){
      var a=-Math.PI/2+2*Math.PI*i/n,rr=radius*ring/3;
      i==0?ctx.moveTo(cx+rr*Math.cos(a),cy+rr*Math.sin(a)):ctx.lineTo(cx+rr*Math.cos(a),cy+rr*Math.sin(a));
    }
    ctx.closePath();ctx.stroke();
  }
  // Axes + labels
  for(var i=0;i<n;i++){
    var a=-Math.PI/2+2*Math.PI*i/n;
    ctx.beginPath();ctx.strokeStyle='#1a1a2e';ctx.moveTo(cx,cy);ctx.lineTo(cx+radius*Math.cos(a),cy+radius*Math.sin(a));ctx.stroke();
    ctx.fillStyle=colors[i];ctx.font='bold 13px system-ui';ctx.textAlign='center';
    ctx.fillText(names[i],cx+(radius+22)*Math.cos(a),cy+(radius+22)*Math.sin(a)+5);
  }
  // Data polygon
  ctx.beginPath();ctx.strokeStyle='#7c4dff';ctx.lineWidth=2;
  var hasData=false;
  for(var i=0;i<n;i++){
    var a=-Math.PI/2+2*Math.PI*i/n,v=vals[i];
    var rr=radius*Math.abs(v)/mx;if(v<0)rr=-rr;
    if(Math.abs(v)>0.01)hasData=true;
    i==0?ctx.moveTo(cx+rr*Math.cos(a),cy+rr*Math.sin(a)):ctx.lineTo(cx+rr*Math.cos(a),cy+rr*Math.sin(a));
  }
  ctx.closePath();ctx.fillStyle='rgba(124,77,255,0.25)';ctx.fill();ctx.stroke();
  // Dots
  for(var i=0;i<n;i++){
    var a=-Math.PI/2+2*Math.PI*i/n,v=vals[i];
    var rr=radius*Math.abs(v)/mx;if(v<0)rr=-rr;
    ctx.beginPath();ctx.arc(cx+rr*Math.cos(a),cy+rr*Math.sin(a),5,0,Math.PI*2);
    ctx.fillStyle=v>0?'#ff4444':v<0?'#4488ff':'#888';ctx.fill();
    ctx.strokeStyle='#fff';ctx.lineWidth=1;ctx.stroke();
  }
  // Radar text summary
  var maxWX='',maxV=0,summaries=[];
  for(var i=0;i<5;i++){
    if(Math.abs(vals[i])>maxV){maxV=Math.abs(vals[i]);maxWX=names[i]}
    if(Math.abs(vals[i])>1)summaries.push(names[i]+(vals[i]>0?'↑':'↓')+Math.abs(vals[i]).toFixed(1));
  }
  if(summaries.length>0){
    ctx.fillStyle='#aaa';ctx.font='11px system-ui';ctx.textAlign='center';
    ctx.fillText(summaries.join('  '),w/2,cy+22);
  }
  ctx.fillStyle='#555';ctx.font='10px system-ui';ctx.textAlign='left';
  ctx.fillText('🔴 外=偏盛 | 🔵 内=偏弱',10,h-8);
  if(!hasData){ctx.fillStyle='#555';ctx.font='13px system-ui';ctx.textAlign='center';ctx.fillText('所有五行均值接近零',w/2,cy+radius+30)}
}

var curTab='radar';
function switchTab(name){
  curTab=name;
  document.querySelectorAll('.tab').forEach(function(t){t.classList.remove('active')});
  document.querySelectorAll('.view').forEach(function(v){v.classList.remove('active')});
  event.target.classList.add('active');
  document.getElementById('view_'+name).classList.add('active');
  if(lastData.length>0)drawRadar(lastData);
}

var lastData=[];

function api(path){fetch(path).then(function(){poll()}).catch(function(e){debug('API错误:'+e)})}
var calDone=false, calRunning=false;

function doCalibrate(){
  if(calRunning)return;calRunning=true;
  var btn=document.getElementById('calStartBtn'),st=document.getElementById('calStatus');
  btn.disabled=true;btn.textContent='校准中…';st.textContent='正在扫描 35 个频段…';
  fetch('/calibrate').then(function(r){return r.json()}).then(function(d){
    if(d.ok){st.innerHTML='<b style=\"color:#00ff88\">✅ 校准成功!</b>';calDone=true;setTimeout(function(){document.getElementById('calOverlay').classList.add('hidden')},1200)}
    else{st.textContent='❌ 失败: '+d.msg;btn.disabled=false;btn.textContent='📐 重试'}
  }).catch(function(){st.textContent='❌ 网络错误';btn.disabled=false;btn.textContent='📐 重试'}).finally(function(){calRunning=false});
}

function setAlgo(mode){
  fetch('/algo?mode='+mode).then(poll);
  document.querySelectorAll('.algo-btn').forEach(function(b){b.classList.remove('active')});
  document.getElementById(mode==='yinyang'?'abYY':mode==='legacy'?'abOLD':mode==='fusion'?'abFUS':'abAB').classList.add('active');
}

function copyLogs(){
  fetch('/api/status').then(function(r){return r.json()}).then(function(s){
    var lines=(s.log||[]).slice(0).reverse();
    var text='NLS 动态平衡 运行日志\\n'+new Date().toLocaleString()+'\\n'+'='.repeat(40)+'\\n';
    text+=lines.join('\\n');
    navigator.clipboard.writeText(text).then(function(){
      var btn=event.target;var orig=btn.textContent;
      btn.textContent='✅ 已复制!';btn.style.color='#00ff88';
      setTimeout(function(){btn.textContent=orig;btn.style.color='#aaa'},1500);
    }).catch(function(){alert('复制失败，请手动选择日志文本')});
  });
}

function stopAndCompare(){
  fetch('/stop').then(function(){return fetch('/api/status')}).then(function(r){return r.json()}).then(function(s){
    var leg=s.ab_legacy||{},yy=s.ab_yinyang||{},fus=s.ab_fusion||{};
    var legR=leg.rounds||0,yyR=yy.rounds||0,fusR=fus.rounds||0;
    if(legR+yyR+fusR<3){alert('至少运行 3 轮交替对比才能出结论');return}

    var legRate=legR>0?(leg.imp/(leg.imp+leg.wors||1)*100).toFixed(0):'-';
    var yyRate=yyR>0?(yy.imp/(yy.imp+yy.wors||1)*100).toFixed(0):'-';
    var fusRate=fusR>0?(fus.imp/(fus.imp+fus.wors||1)*100).toFixed(0):'-';

    var rates=[{name:'同频反相',rate:legRate,leg,color:'#ffaa00'},
               {name:'☀☽双频',rate:yyRate,yy,color:'#7c4dff'},
               {name:'⚡融合',rate:fusRate,fus,color:'#44dd88'}];
    rates.sort(function(a,b){return b.rate-a.rate});
    var winner=rates[0].rate>rates[1].rate?rates[0].name+(' 更好! (+'+(rates[0].rate-rates[1].rate)+'%)'):'难分伯仲';

    var card=document.getElementById('resultCard'),body=document.getElementById('resultBody');
    var h='<div style=\"display:flex;gap:6px;margin:8px 0\">';
    var colors={leg:'#ffaa00',yy:'#7c4dff',fus:'#44dd88'};
    var items=[{key:'leg',name:'同频反相',rate:legRate,d:leg,color:'#ffaa00'},
               {key:'yy',name:'☀☽双频',rate:yyRate,d:yy,color:'#7c4dff'},
               {key:'fus',name:'⚡融合',rate:fusRate,d:fus,color:'#44dd88'}];
    for(var i=0;i<items.length;i++){
      var it=items[i];
      h+='<div style=\"flex:1;background:#141420;padding:8px;border-radius:8px;text-align:center;border-top:3px solid '+it.color+'\">'+
        '<div style=\"color:#888;font-size:9px\">'+it.name+'</div>'+
        '<div style=\"font-size:20px;font-weight:bold;color:'+it.color+'\">'+it.rate+'%</div>'+
        '<div style=\"font-size:9px;color:#666\">'+it.d.rounds+'轮 改善'+it.d.imp+'/恶化'+it.d.wors+'</div></div>';
    }
    h+='</div><div style=\"text-align:center;font-size:14px;font-weight:bold;color:#00ff88;padding:8px\">🏆 '+winner+'</div>';
    body.innerHTML=h;
    card.style.display='block';
    card.scrollIntoView({behavior:'smooth'});
  });
}

function poll(){
  fetch('/api/status').then(function(r){return r.json()}).then(function(s){
    dbg.style.display='none';
    var cb=document.getElementById('conn_badge');
    cb.textContent=s.connected?'🟢 手环已连接':'⚪ 未连接';
    cb.style.background=s.connected?'#0a3a1a':'#333';
    cb.style.color=s.connected?'#00ff88':'#888';

    var btnS=document.getElementById('btnStart'),btnX=document.getElementById('btnStop'),btnC=document.getElementById('btnCmp');
    if(s.playing||s.scanning){btnS.style.display='none';btnX.style.display='inline-block';btnC.style.display='inline-block'}
    else{btnS.style.display='inline-block';btnX.style.display='none';btnC.style.display='none'}

    // Calibration overlay auto-trigger
    var ov=document.getElementById('calOverlay');
    if(s.connected&&!s.has_baseline&&!calDone){
      ov.classList.remove('hidden');
    }else if(calDone||s.has_baseline){
      ov.classList.add('hidden');
    }

    // Baseline dot
    document.getElementById('baselineDot').style.background=s.has_baseline?'#00ff88':'#f44';

    var st=document.getElementById('stats');
    if(s.playing){
      var algoNames={legacy:'同频反相',yinyang:'☀☽双频',fusion:'⚡融合'};
      var curAlgo=s.current_algo||(function(){var r3=s.round%3||3;return r3==1?'legacy':(r3==2?'yinyang':'fusion')})();
      st.innerHTML='<b>● 第'+s.round+'轮</b> ['+algoNames[curAlgo]+'] | 改善<b>'+s.improved+'</b> 恶化<b>'+s.worsened+'</b>';
    }
    else if(!s.connected){st.innerHTML='<span style="color:#ffaa00">⚠ 未检测到手环</span>'}
    else if((s.log||[])[0]&&s.log[0].indexOf('✅ 基线')>=0){st.innerHTML='<b style="color:#00ff88">✅ 基线校准完成!</b>'}
    else if((s.log||[])[0]&&s.log[0].indexOf('📐 校准')>=0){st.innerHTML='<span style="color:#ffaa00">📐 校准中...</span>'}
    else{st.innerHTML='○ 待机'}

    // 3-way comparison stats + bars
    var ab=document.getElementById('abStats'),leg=s.ab_legacy||{},yy=s.ab_yinyang||{},fus=s.ab_fusion||{};
    var legRate=leg.rounds>0?(leg.imp/(leg.imp+leg.wors||1)*100).toFixed(0):'-';
    var yyRate=yy.rounds>0?(yy.imp/(yy.imp+yy.wors||1)*100).toFixed(0):'-';
    var fusRate=fus.rounds>0?(fus.imp/(fus.imp+fus.wors||1)*100).toFixed(0):'-';
    ab.innerHTML='旧:'+legRate+'%('+leg.rounds+'轮) 双频:'+yyRate+'%('+yy.rounds+'轮) 融合:'+fusRate+'%('+fus.rounds+'轮)';
    // distribution bars
    var total=Math.max(1,leg.rounds+yy.rounds+fus.rounds);
    document.getElementById('barLeg').style.width=(leg.rounds/total*100).toFixed(0)+'%';
    document.getElementById('barYY').style.width=(yy.rounds/total*100).toFixed(0)+'%';
    document.getElementById('barFus').style.width=(fus.rounds/total*100).toFixed(0)+'%';

    var items=Object.values(s.deltas||{});
    // Always sort once
    items.sort(function(a,b){return Math.abs(b.delta)-Math.abs(a.delta)});
    lastData=items;

    if(items.length>0){
      try{drawRadar(items)}catch(e){debug('雷达图错误:'+e.message)}
    }

    // List (always visible in its tab)
    var dl=document.getElementById('deltas');
    if(items.length>0){
      var h='';
      for(var i=0;i<items.length;i++){
        var o=items[i],ad=Math.abs(o.delta),c=ad>8?'#ff4444':ad>4?'#ffaa00':'#00ff88';
        var vfy=o.verified!=null?' <span style="font-size:9px;color:'+(o.verified>0?'#00ff88':'#ff4444')+'">'+(o.verified>0?'↓'+o.verified:'↑'+Math.abs(o.verified))+'</span>':'';
        var yy=' <span style=\"font-size:8px;color:#666\">'+(o.sun>o.moon?'☀'+o.sun_b9:'☽'+o.moon_b9)+'</span>';
        h+='<div class="row">'
          +'<span>'+o.organ+yy+'</span>'
          +'<span class="badge" style="color:'+c+'">Δ'+o.delta.toFixed(1)+vfy+'</span>'
          +'</div>';
      }
      dl.innerHTML=h;
    }else{dl.innerHTML='<div style="color:#555;text-align:center;padding:20px">等待扫描数据…</div>'}

    var lg=document.getElementById('log');
    lg.innerHTML=(s.log||[]).slice(0,20).map(function(l){return'<div>'+l+'</div>'}).join('');
  }).catch(function(e){debug('状态解析错误:'+e)});
}
setInterval(poll,1500);poll();
</script></body></html>"""


class WebHandler(BaseHTTPRequestHandler):
    balancer = None

    def log_message(self, *args): pass

    def send_json(self, data):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, default=str).encode())

    def do_GET(self):
        p = urlparse(self.path)
        if p.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML.encode())
        elif p.path == "/api/status":
            with self.balancer._lock:
                self.send_json(self.balancer.status)
        elif p.path == "/start":
            if not self.balancer.running:
                self.balancer.status["deltas"] = {}
                self.balancer.status["log"] = self.balancer.status["log"]
                threading.Thread(target=self.balancer.loop, daemon=True).start()
            self.send_json({"ok": True})
        elif p.path == "/stop":
            self.balancer.running = False
            with self.balancer._lock:
                self.balancer.status["playing"] = False
                self.balancer.status["scanning"] = False
            self.send_json({"ok": True})
        elif p.path == "/algo":
            qs = parse_qs(p.query)
            mode = qs.get("mode", ["yinyang"])[0]
            with self.balancer._lock:
                self.balancer.status["algo"] = mode
                if mode != "ab":
                    self.balancer.status["ab_legacy"] = {"imp": 0, "wors": 0, "rounds": 0}
                    self.balancer.status["ab_yinyang"] = {"imp": 0, "wors": 0, "rounds": 0}
                    self.balancer.status["ab_fusion"] = {"imp": 0, "wors": 0, "rounds": 0}
            self.send_json({"ok": True, "algo": mode})
        elif p.path == "/calibrate":
            if not self.balancer.ser or not self.balancer.ser.is_open:
                self.send_json({"ok": False, "msg": "手环未连接"})
                return
            if self.balancer.calibrating:
                self.send_json({"ok": False, "msg": "校准进行中，请稍候"})
                return
            threading.Thread(target=self.balancer.calibrate, daemon=True).start()
            self.send_json({"ok": True, "msg": "校准中…"})
        else:
            self.send_response(404)
            self.end_headers()


def main():
    b = Balancer()
    WebHandler.balancer = b
    server = HTTPServer(("0.0.0.0", 8080), WebHandler)
    server.socket.setsockopt(__import__('socket').SOL_SOCKET, __import__('socket').SO_REUSEADDR, 1)
    print("[OK] http://127.0.0.1:8080")

    # 后台尝试连接手环，先启动服务不阻塞
    def _bg_connect():
        time.sleep(0.3)
        if b.connect():
            print("[OK] COM4 已连接")
        else:
            print("[INFO] COM4 未连接 — Web界面已可用")

    threading.Thread(target=_bg_connect, daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        b.disconnect()
        server.server_close()


if __name__ == '__main__':
    main()
